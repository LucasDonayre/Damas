#ifndef C___MATRIZ_H
#define C___MATRIZ_H

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Matriz{
private:
    int dimensiones=8;
    string **tablero;
public:
    string** gettablero();
    void generar_tablero();
    void imprimir_tablero();
    void colocar_fichas_blancas(int cantidad_fichas, vector<vector<int>> posiciones_de_fichas);
    void colocar_fichas_negras(int cantidad_fichas, vector<vector<int>> posiciones_de_fichas);
    void mover_ficha(vector<int> posicion_inicial, vector<int> posicion_final, int contador);
    bool verificar_posicion_blanca(vector<int> posicion_blanca, vector<int> posicion_final_blanca);
    bool verificar_posicion_negra(vector<int> posicion_ficha_negra, vector<int> posicion_final_negra);
    void borrar_tablero();
};

#endif //C___MATRIZ_H
