#include "Matriz.h"
#include "Fichas.h"

void Matriz::generar_tablero(){
    tablero = new string*[dimensiones];
    for(int i=0;i<dimensiones;i++){
        tablero[i]=new string[dimensiones];
        for(int j=0;j<dimensiones;j++){
            if((j+i)%2==0 ){
                tablero[i][j]="B";
            }else{
                tablero[i][j]="N";
            }
        };
    }
}



void Matriz::colocar_fichas_blancas(int cantidad_fichas, vector<vector<int>> posiciones_de_fichas){
    int x;
    int y;
    for(int i=0;i<cantidad_fichas;i++){
        x=posiciones_de_fichas[i][1];
        y=posiciones_de_fichas[i][0];
        tablero[y][x]="*";
    }
};

void Matriz::colocar_fichas_negras(int cantidad_fichas, vector<vector<int>> posiciones_de_fichas){
    int x;
    int y;
    for(int i=0;i<cantidad_fichas;i++){
        x=posiciones_de_fichas[i][1];
        y=posiciones_de_fichas[i][0];
        tablero[y][x]="o";
    }
};

void Matriz::mover_ficha(vector<int> posicion_inicial, vector<int> posicion_final, int contador){
    if(tablero[posicion_inicial[0]][posicion_inicial[1]]=="*" and verificar_posicion_blanca(posicion_inicial, posicion_final) and contador%2==0){
        tablero[posicion_final[0]][posicion_final[1]]="*";
        tablero[posicion_inicial[0]][posicion_inicial[1]]="N";
    }else if(tablero[posicion_inicial[0]][posicion_inicial[1]]=="o" and verificar_posicion_negra(posicion_inicial, posicion_final) and contador%2!=0){
        tablero[posicion_final[0]][posicion_final[1]]="o";
        tablero[posicion_inicial[0]][posicion_inicial[1]]="B";
    }
};

bool Matriz::verificar_posicion_blanca(vector<int> posicion_ficha_blanca, vector<int> posicion_final_blanca){
    if(tablero[posicion_final_blanca[0]][posicion_final_blanca[1]]=="N"){
        if(posicion_ficha_blanca[0]+1==posicion_final_blanca[0] and posicion_ficha_blanca[1]+1==posicion_final_blanca[1]){
            return true;
        }
    }else if(tablero[posicion_ficha_blanca[0]+1][posicion_ficha_blanca[1]+1]=="o"){

    }
};
bool Matriz::verificar_posicion_negra(vector<int> posicion_ficha_negra, vector<int> posicion_final_negra){
    if(tablero[posicion_final_negra[0]][posicion_final_negra[1]]=="B" and posicion_ficha_negra[0]-1==posicion_final_negra[0] and posicion_ficha_negra[1]-1== posicion_final_negra[1]){
        return true;
    }
};


void Matriz::imprimir_tablero() {
    for(int i=0;i<dimensiones;i++){
        for(int j=0;j<dimensiones;j++){
            cout<<tablero[i][j];
        }
        cout<<endl;
    }
}


void Matriz::borrar_tablero(){
    for(int i=0;i<dimensiones;i++){
        delete[] tablero[i];
    }
    delete[] tablero;
}