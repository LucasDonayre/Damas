#include "Fichas.h"

int busqueda_lineal(const vector<string>& array,const string& elemento){
    int posicion=0;
    for(int i=0;i<array.size();i++){
        if(elemento==array[i]){
            posicion=i;
        }
    }
    return posicion;
};

int Cficha_blanca::get_cantidad_De_fichas(){
    return cantidad_de_fichas;
}

vector<int> Cficha_blanca::get_nueva_posicion_blanca(){
    return nueva_posicion_blanca;
};

vector<string> Cficha_blanca::get_fichas(){
    return fichas_blancas;
};

vector<vector<int>> Cficha_blanca::get_posiciones_de_fichas(){
    return posicion_blancas;
};



//Ficha negras



int Cficha_negra::get_cantidad_De_fichas(){
    return cantidad_de_fichas;
};


vector<int> Cficha_negra::get_nueva_posicion_negra(){
    return nueva_posicion_negra;
};


vector<string> Cficha_negra::get_fichas(){
    return fichas_negras;
};


vector<vector<int>> Cficha_negra::get_posiciones_de_fichas(){
    return posicion_negras;
};