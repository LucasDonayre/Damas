#ifndef C___FICHAS_H
#define C___FICHAS_H

#include <vector>
#include <iostream>
#include <string>
using namespace std;

int busqueda_lineal(const vector<string>& array,const string& elemento);


class Cficha_blanca {
private:
    int cantidad_de_fichas=12;
    vector<string> fichas_blancas={"*","*","*","*","*","*","*","*","*","*","*","*"};
    vector<vector<int>> posicion_blancas={{0,1},{0,3},{0,5},{0,7},{1,0},{1,2},{1,4},{1,6},{2,1},{2,3},{2,5},{2,7}};
    vector<int> nueva_posicion_blanca;
public:
    int get_cantidad_De_fichas();
    vector<int> get_nueva_posicion_blanca();
    vector<string> get_fichas();
    vector<vector<int>> get_posiciones_de_fichas();
};

//Ficha negra

class Cficha_negra{
private:
    int cantidad_de_fichas=12;
    vector<string> fichas_negras={"$","$","$","$","$","$","$","$","$","$","$","$"};
    vector<vector<int>> posicion_negras={{5,0},{5,2},{5,4},{5,6},{6,1},{6,3},{6,5},{6,7},{7,0},{7,2},{7,4},{7,6}};
    vector<int> nueva_posicion_negra;
public:
    int get_cantidad_De_fichas();
    vector<int> get_nueva_posicion_negra();
    vector<string> get_fichas();
    vector<vector<int>> get_posiciones_de_fichas();
};

#endif //C___FICHAS_H
