#include "Fichas.h"
#include "Matriz.h"

int main(){
    Cficha_blanca fichas_blancas;
    Cficha_negra fichas_negras;
    int contador=0;
    int J=0;
    int X_cambio;
    int Y_cambio;
    int X_final;
    int Y_final;
    Matriz Damas;
    Damas.generar_tablero();
    Damas.imprimir_tablero();
    cout<<"\n";
    Damas.colocar_fichas_blancas(fichas_blancas.get_cantidad_De_fichas(),fichas_blancas.get_posiciones_de_fichas());
    Damas.imprimir_tablero();
    cout<<"\n";
    Damas.colocar_fichas_negras(fichas_negras.get_cantidad_De_fichas(),fichas_negras.get_posiciones_de_fichas());
    Damas.imprimir_tablero();
    cout<<"\n";
    cout<<"Donde desea cambiar la ficha negra?"<<endl;
    cout<<"1. Derecha"<<endl;
    cout<<"2. Izquierda"<<endl;cin>>J;
    Damas.colocar_fichas_negras(fichas_negras.get_cantidad_De_fichas(),fichas_negras.get_posiciones_de_fichas());
    Damas.imprimir_tablero();
    cout<<endl;
    cout<<"Donde desea cambiar la ficha blanca?"<<endl;
    cout<<"1. Derecha"<<endl;
    cout<<"2. Izquierda"<<endl;cin>>J;
    Damas.colocar_fichas_negras(fichas_negras.get_cantidad_De_fichas(),fichas_negras.get_posiciones_de_fichas());
    Damas.imprimir_tablero();
    cout<<"Gano la ficha blanca!!"<<endl;
    cin>>X_cambio>>Y_cambio>>X_final;
    Damas.mover_ficha({X_cambio,Y_cambio},{X_final,Y_final},contador);
    cin>>X_cambio>>Y_cambio>>X_final;
    Damas.mover_ficha({X_cambio,Y_cambio},{X_final,Y_final},contador);
    Damas.imprimir_tablero();

    Damas.borrar_tablero();
}
